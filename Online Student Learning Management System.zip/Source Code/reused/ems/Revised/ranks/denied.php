<?php

session_start();

include "access.php";
include "header.php";
?>

    <h1>Access Denied!</h1>

<?php include "footer.php" ?>