<?php

session_start();

include "access.php";
access('ADMIN');

include "header.php";
?>

    <h1>This is the admin page</h1>

    <form method="post">
            <select>
                <option>user</option>
                <option>accountant</option>
                <option>receptionist</option>
                <option>admin</option>
                <option>profile</option>
            </select>
    </form>

<?php include "footer.php" ?>