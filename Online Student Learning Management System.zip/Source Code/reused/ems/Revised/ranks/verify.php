<!DOCTYPE html>

<html>
<head>
    <meta charset="utf-8">
    <title>Verify</title>
</head>
<body>

    <?php 
        include('header.php')
    ?>


</body>




</html>