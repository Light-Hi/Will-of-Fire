<?php

session_start();

//check_login();


include('header.php');

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    if (!$DB = new PDO("mysql:host=localhost;dbname=ranks_db", "root", "")) {
        die("Could not connect to the database");
    }


    /*echo "<pre>";
        print_r($_POST);
        echo "<pre>";*/

    //Select from database
    $arr['name'] = $_POST['name'];
    $arr['email'] = $_POST['email'];
    $arr['address'] = $_POST['address'];
    $arr['phone'] = $_POST['phone'];
    $arr['salary'] = $_POST['salary'];
    $arr['ssn'] = $_POST['ssn'];
    $arr['password'] = hash('sha1', $_POST['password']);
    $arr['rank'] = "user";

    $query = "select * from users where userid = :userid && name = :name && email = :email && address = :address && phone = :phone && salary = :salary && ssn = :ssn && password = :password, && rank = :rank limit 1";
    $stm = $DB->prepare($query);
    if ($stm) {
        echo $query;
        $check = $stm->execute($arr);
        if (!$check) {
            $error = "Could not get user data from database";
        }

        if ($error == "") {
            header("Location: login.php");
            die;
        }
    }
}

?>

<h1>This is the profile page

    (Include img, style, password change function, etc.)

</h1>

<!DOCTYPE html>
<html>

<head>
    <meta content='text/html; charset=UTF-8' http-equiv='Content-Type' />
    <link rel="stylesheet" type="text/css" href="style.css" />
    <title>Profile</title>
</head>

<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Employee Portal</a></li>
                <li><a href="profile.php">Profile</a></li>
            </ul>
        </nav>
    </header>
    <div id="center">
        <div id="center-set">
            <div id="signup">
                <div id="signup-st">
                    <div align="center">
                        <?php
                        $remarks = isset($_GET['remarks']) ? $_GET['remarks'] : '';
                        if ($remarks == null and $remarks == "") {
                            echo ' <div id="reg-head" class="headrg">Profile</div> ';
                        }
                        if ($remarks == 'success') {
                            echo ' <div id="reg-head" class="headrg">Registration Success</div> ';
                        }
                        if ($remarks == 'failed') {
                            echo ' <div id="reg-head-fail" class="headrg">Registration Failed!, Username exists</div> ';
                        }
                        if ($remarks == 'error') {
                            echo ' <div id="reg-head-fail" class="headrg">Registration Failed! <br> Error: ' . $_GET['value'] . ' </div> ';
                        }
                        ?>
                    </div>

                    <?php
                    require_once('connection.php');
                    $result = $conn->prepare("SELECT * FROM users ORDER BY userid ASC limit 1");
                    $result->execute();
                    for ($i = 0; $row = $result->fetch(); $i++) {
                    ?>
                        <tr>

                            <br>
                            <th>id:</th>
                            <td><label><?php echo $row['userid']; ?></label></td><br>

                            <br>
                            <th>name: </th>
                            <td><label><?php echo $row['name']; ?></label></td><br>

                            <br>
                            <th>email: </th>
                            <td><label><?php echo $row['email']; ?></label></td><br>

                            <br>
                            <th>address: </th>
                            <td><label><?php echo $row['address']; ?></label></td><br>

                            <br>
                            <th>Phone: </th>
                            <td><label><?php echo $row['phone']; ?></label></td><br>

                            <br>
                            <th>salary: </th>
                            <td><label><?php echo $row['salary']; ?></label></td><br>

                            <br>
                            <th>ssn: </th>
                            <td><label><?php echo $row['ssn']; ?></label></td><br>
                        </tr>
                    <?php } ?>


                    <style type="text/css">
                        body {
                            width: 800px;
                            margin: auto;
                            padding: 10px;
                        }

                        tr {
                            text-align: center;
                            padding: 10px;
                        }

                        table {
                            margin: auto;
                            border: blue 1px solid;
                        }

                        label {
                            font-size: 18px;
                            color: blue;
                            font-weight: bold;
                            font-family: cursive;
                        }

                        h2 {
                            color: red;
                            text-align: center;
                        }

                        th {
                            color: red;
                            font-size: 20px;
                            font-family: cursive;
                        }
                    </style>

                    <?php include "footer.php" ?>