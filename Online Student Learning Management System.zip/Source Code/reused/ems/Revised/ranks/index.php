<?php

session_start();


include "header.php";
?>

    <h1>This is the home page</h1>

<?php include "footer.php" ?>

<!DOCTYPE html>
<html>

<head>
    <meta content='text/html; charset=UTF-8' http-equiv='Content-Type' />
    <link rel="stylesheet" type="text/css" href="style.css" />
    <title>Login</title>
</head>

<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Employee Portal</a></li>
                <li><a href="profile.php">Profile</a></li>

            </ul>
        </nav>
    </header>
    <div id="center">
        <div id="center-set"> 
            <div id="signup">
                <div id="signup-st">
                    <div align="center">
                        <?php
                        $remarks = isset($_GET['remarks']) ? $_GET['remarks'] : '';
                        if ($remarks == null and $remarks == "") {
                            echo ' <div id="reg-head" class="headrg">Content</div> ';
                        }
                        if ($remarks == 'success') {
                            echo ' <div id="reg-head" class="headrg">Registration Success</div> ';
                        }
                        if ($remarks == 'failed') {
                            echo ' <div id="reg-head-fail" class="headrg">Registration Failed!, Username exists</div> ';
                        }
                        if ($remarks == 'error') {
                            echo ' <div id="reg-head-fail" class="headrg">Registration Failed! <br> Error: ' . $_GET['value'] . ' </div> ';
                        }
                        ?>
                    </div>
                    