<!DOCTYPE html>

<html>

<head>
    <title>Home</title>
</head>

<style type="text/css">
    body,
    li,
    ul {
        margin: 0px auto;
    }

    body {
        background-color: #3498DB;
        width: 100%;
        font-family: sans-serif;
    }

    header {
        background-color: #fff;
        width: 100%;
        height: 55px;
        margin: 0px;
    }

    nav {
        width: 100%;
        border-top: 5px solid #3498DB;
    }

    nav ul {
        float: left;
        border-left: 6px solid #BDC3C7;
        height: 50px;
    }

    nav a {
        text-decoration: none;
        color:rgba(0, 0, 0, 0.85);
        padding: 10px;
        width: auto;
        font-size: 30px;
        font-weight: bold;
        border-right: 1px solid #BDC3C7;
        font-family: Gabriola;
        height: 50px;
    }

    nav a:hover {
        color: #fff;
        background-color: #3498DB;
        transition: 1s;
    }

    nav li {
        margin: 0;
        padding: 0;
        list-style: none;
        float: left;
    }

    #center {
        margin: 0px auto;
        width: 95%;
    }

    #center-set {
        float: left;
        width: 100%;
        padding-top: 1%;
        padding-bottom: 0.5%;
        background-color: #A2DED0;
        border-top: 5px solid #3498DB;
    }

    #signup {
        float: left;
        width: 50%;
    }

    #signup-st,
    #login-st {
        background-color: #6C7A89;
        margin: 50px;
        border-radius: 20px;
        box-shadow: #3498DB;
        -webkit-box-shadow: 3px 3px 4px 0px rgba(0, 0, 0, 0.85);
    }

    #reg {
        padding-top: 10px;
    }

    #reg-head,
    #reg-bottom,
    #reg-head-fail {
        width: 100%;
        text-align: center;
        background-color: #fff;
        font-weight: bold;
    }

    .headrg {
        border-top-left-radius: 20px;
        border-top-right-radius: 20px;
        padding-top: 12px;
        padding-bottom: 12px;
        font-size: 22px;
        color:rgba(0, 0, 0, 0.85);
    }

    .btmrg {
        padding-top: 5px;
        padding-bottom: 5px;
        border-bottom-left-radius: 20px;
        border-bottom-right-radius: 20px;
        font-size: 18px;
        color:rgba(0, 0, 0, 0.85);
    }

    #reg-head-fail {
        color:rgba(0, 0, 0, 0.85);
    }

    #reg-head:hover {
        color: #3498DB;
        transition: 1s;
    }

    #tb-name {
        float: right;
        font-size: 20px;
    }

    #tb-box {
        height: 22px;
        width: 200px;
    }

    #st {
        width: 100%;
        text-align: center;
        padding-top: 30px;
        padding-bottom: 10px;
    }

    #st-btn {
        text-align: center;
        padding: 10px 21px 10px 21px;
        background-color: #3498DB;
        border: none;
        color:rgba(0, 0, 0, 0.85);
        cursor: pointer;
        font-size: 20px;
        font-weight: bold;
    }

    #st-btn:hover {
        color: #3498DB;
        background: #fff;
        transition: 1s;
    }

    td.t-1 {
        float: left;
        width: 44%;
        text-align: right;
        color:rgba(0, 0, 0, 0.85);
    }

    td.t-2 {
        float: right;
        width: 55%;
    }

    #lg-1 {
        padding: 10px;
        float: left;
        width: 95%;
    }

    .tl-1 {
        float: left;
        width: 40%;
        padding-right: 5%;
        text-align: center;
        color: #C5EFF7;
    }

    .tl-4 {
        font-size: 17px;
        font-weight: bold;
        text-align: center;
        color:rgba(0, 0, 0, 0.85);
    }

    #login {
        float: right;
        width: 50%;
    }

    #login-sg {
        margin-top: 20%;
    }

    #footer {
        background-color: #fff;
        width: 100%;
        height: 50px;
        margin: 0px;
        float: left;
        border-top:rgba(0, 0, 0, 0.85);
    }

    #footer p {
        text-align: center;
        font-size: 18px;
        font-weight: bold;
        color:rgba(0, 0, 0, 0.85);
    }
</style>

<body>

    <header><a href="index.php"> Home</a> . <a href="admin.php">Admin</a> . <a href="acc.php">Accountant</a> . <a href="rec.php">Receptionist</a> . <a href="profile.php"> Profile</a> . <a href="login.php">Login</a> . <a href="signup.php">Signup</a> . <a href="logout.php">Logout</a> </header>

    <span>
        <?php

        if (isset($_SESSION['myname'])) {
            echo "Hi, " . $_SESSION['myname'];
        }
        ?>
        <?php //if(access('ADMIN', true)): //Add things only an admin needs access to
        ?>
        <?php //endif; 
        ?>
    </span>