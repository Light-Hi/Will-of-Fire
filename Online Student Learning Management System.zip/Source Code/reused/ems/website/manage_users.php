<!DOCTYPE html>

<html>
<head>
    <title>
        Manage_Users
    </title>




</head>
<body>
    <h1>This is where the admin manages users</h1>

</body>




</html>