<?php include('session.php');
?>

<head>
    <meta content='text/html; charset=UTF-8' http-equiv='Content-Type' />
    <link rel="stylesheet" type="text/css" href="style.css" />
    <title>Profile Page</title>
</head>

<body>
    <header>
        <nav>
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="services.php">Services</a></li>
                <li><a href="admintools.php">Admin Tools</a></li>
            </ul>
        </nav>
    </header>
    <?php
                $sql = "SELECT * FROM member where mem_id=$loggedin_id";
                $result = mysqli_query($con, $sql);
                ?>
    <?php
    
    while ($rows = mysqli_fetch_array($result)) {
    ?>
        <div id="center">
            <div id="center-set">
                <h1 align='center'>Welcome <?php echo $loggedin_session; ?>,</h1>
                You are now logged in. you can logout by clicking on signout link. 
                Make sure to set the user type in phpMyAdmin. One for "user" and one for "admin".
                <div id="contentbox">
                    <div id="signup">
                        <div id="signup-st">
                            <form action="" method="POST" id="signin" id="reg">
                                <div id="reg-head" class="headrg">Admin Profile</div>
                                <table border="0" align="center" cellpadding="2" cellspacing="0">
                                    <tr id="lg-1">
                                        <td class="tl-1">
                                            <div align="left" id="tb-name">Reg id:</div>
                                        </td>
                                        <td class="tl-4"><?php echo $rows['mem_id']; ?></td>
                                    </tr>
                                    <tr id="lg-1">
                                        <td class="tl-1">
                                            <div align="left" id="tb-name">Username:</div>
                                        </td>
                                        <td class="tl-4"><?php echo $rows['username']; ?></td>
                                    </tr>
                                    <tr id="lg-1">
                                        <td class="tl-1">
                                            <div align="left" id="tb-name">User-Type:</div>
                                        </td>
                                        <td class="tl-4"><?php echo $rows['user_type']; ?></td>
                                    </tr>
                                    <tr id="lg-1">
                                        <td class="tl-1">
                                            <div align="left" id="tb-name">Name:</div>
                                        </td>
                                        <td class="tl-4"><?php echo $rows['fname']; ?> <?php echo $rows['lname']; ?></td>
                                    </tr>
                                    <tr id="lg-1">
                                        <td class="tl-1">
                                            <div align="left" id="tb-name">Address:</div>
                                        </td>
                                        <td class="tl-4"><?php echo $rows['address']; ?></td>
                                    </tr>
                                    <tr id="lg-1">
                                        <td class="tl-1">
                                            <div align="left" id="tb-name">Phone:</div>
                                        </td>
                                        <td class="tl-4"><?php echo $rows['phone']; ?></td>
                                    </tr>
                                    <tr id="lg-1">
                                        <td class="tl-1">
                                            <div align="left" id="tb-name">Salary:</div>
                                        </td>
                                        <td class="tl-4"><?php echo $rows['salary']; ?></td>
                                    </tr>
                                    <tr id="lg-1">
                                        <td class="tl-1">
                                            <div align="left" id="tb-name">SSN:</div>
                                        </td>
                                        <td class="tl-4"><?php echo $rows['ssn']; ?></td>
                                    </tr>
                                    <tr id="lg-1">
                                        <td class="tl-1">
                                            <div align="left" id="tb-name">Email:</div>
                                        </td>
                                        <td class="tl-4"><?php echo $rows['email']; ?></td>
                                    </tr>
                                    <tr id="lg-1">
                                        <td class="tl-1">
                                            <div align="left" id="tb-name">Password:</div>
                                        </td>
                                        <td class="tl-4"><?php echo $rows['password']; ?></td>
                                    </tr>
                                </table>
                                <div id="reg-bottom" class="btmrg">Update Profile btn</div>
                            </form>
                        </div>
                    </div>
                    <div id="login">
                        <div id="login-sg">
                            <div id="st"><a href="logout.php" id="st-btn">Sign Out</a></div>
                            <div id="st"><a href="deleteac.php" id="st-btn">Delete Account</a></div>
                            <div id="st"><a href="manage_users.php" id="st-btn">Manage Users</a></div>
                        </div>
                    </div>

                <?php
                // close while loop 
            }
                ?>

                </div>
            </div>
        </div>
        </br>
        <div id="footer">
            <p>This is the Profile Page</p>
        </div>
</body>

</html>