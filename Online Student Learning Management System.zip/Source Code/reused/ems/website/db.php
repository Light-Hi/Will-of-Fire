<?php
$mysqli_hostname = "localhost";
$mysqli_user = "root";
$mysqli_password = "";
$mysqli_database = "database";
 
$con = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password, $mysqli_database);

?>