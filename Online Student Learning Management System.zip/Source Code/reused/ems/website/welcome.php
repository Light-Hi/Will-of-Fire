<?php
include('session.php');
?>
<!DOCTYPE html>
<html>

<head>
    <meta content='text/html; charset=UTF-8' http-equiv='Content-Type' />
    <link rel="stylesheet" type="text/css" href="style.css" />
    <title>Profile Page</title>
</head>

<body>
    <header>
        <nav>
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="">Services</a></li>
            </ul>
        </nav>
    </header>
    <div id="center">
        <div id="center-set"> 
            <h1 align='center'>Welcome <?php echo $loggedin_session; ?>,</h1>
            You are now logged in. you can logout by clicking on signout link. 
            Make sure to set the user type in phpMyAdmin. One for user and one for admin. 
            <div id="contentbox">
                <?php
                $sql = "SELECT * FROM member where mem_id=$loggedin_id";
                $result = mysqli_query($con, $sql);
                ?>
                <?php
                while ($rows = mysqli_fetch_array($result)) {
                    if($rows["user_type"] == "user")
                    {
                        header("location: user.php");
                    }
                    elseif($rows["user_type"] == "admin")
                    {
                        header("location: admin.php");
                        
                    }
                    else
                    {
                        echo "username or password is incorrect";
                    }
                ?> 
                    
                <?php
                    // close while loop 
                }
                ?>
            </div>
        </div>
    </div>
    </br>
    <div id="footer">
        <p>This is the Profile Page</p>
    </div>
</body>

</html>