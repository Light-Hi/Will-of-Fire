<!DOCTYPE html>

<html>
<head>
    <title>
        Services
    </title>




</head>
<body>
    <h1>This is where company services and resources can be accessed</h1>

</body>




</html>