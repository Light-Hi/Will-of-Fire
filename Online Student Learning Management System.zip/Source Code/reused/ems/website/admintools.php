<!DOCTYPE html>

<html>
<head>
    <title>
        admintools
    </title>




</head>
<body>
    <h1>This is where tools are offered to administrators</h1>

</body>




</html>