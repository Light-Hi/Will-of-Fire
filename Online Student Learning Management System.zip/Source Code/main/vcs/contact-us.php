<!DOCTYPE html>
<html lang="en">
<head>
	<?php 
		include 'head.php'; 
	?>
</head>

<body>

    <?php include 'navbar.php'; ?>

	<div class="wrapper">
        <div class="landing">
            <div style="padding-top: 65px;">
			<h1 class="brand">Online Student Learning Management System</h1> <?php //needs bootstrap and padding?>
            <div class="landing__bg"></div>
            <div class="content">

	<div class="col-md-4">
					<h3 class="text-center">CONTACT INFO</h3><strong>Contact Info</strong>
					<p>(888) 888-8888<br>
					email@nuno.com</p>
				</div>




    <?php include 'footer.php'; ?>
	<?php include 'scripts.php'; ?>

</body>
</html>