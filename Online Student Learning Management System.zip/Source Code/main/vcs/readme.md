# **Simple E-Learning System in PHP**

### **Recommended PHP Version >= 7.4**

==============================================================================================
## **Origianl Version Information**
- **Developed by:** Shubiour Shuvo
- **Download From:** [https://freeprojectscodes.com/virtual-classroom-project-in-php-mysql-with-source-code/](https://freeprojectscodes.com)
==============================================================================================
## **Modified Version Information**
- **Modified by:** oretnom23
- **Download From:** [https://sourcecodester.com/php-simple-e-learning-system-source-code/](https://sourcecodester.com)
==============================================================================================


==============================================================================================
## **Sample Access**
- **Email:** cblake@mail.com
- **Password:** cblake123
==============================================================================================
- **Email:** jforeman@mail.com
- **Password:** jforeman123
==============================================================================================
