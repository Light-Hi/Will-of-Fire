<!DOCTYPE html>
<html lang="en">

<head>
	<?php
	include 'head.php';
	?>
</head>

<body>

	<?php include 'navbar.php'; ?>

	<div class="wrapper">
        <div class="landing">
            <div style="padding-top: 65px;">
			<h1 class="brand">Online Student Learning Management System</h1> <?php //needs bootstrap and padding?>
            <div class="landing__bg"></div>
            <div class="content">
	<div class="wrapper">
		<div class="landing">
			<div style="padding-top: 65px;">
			<h1 class="brand">E-Learning System</h1> <?php //needs padding?>
			<div class="landing__bg"></div>
			<div class="content">
				<div id="second">
					<form action="landing_page.php" method="POST" id="register-form">
						<input type="text" name="reg_fname" placeholder="First name" value="<?php
																							if (isset($_SESSION['reg_fname'])) {
																								echo $_SESSION['reg_fname'];
																							} ?>" required>

						<br>

						<?php //if (in_array("Email already in use<br>", $error_array)) echo "Email already in use<br>"; 
						// Have to work on these 
						?>

						<input type="text" name="reg_lname" placeholder="Last name" value="<?php
																							if (isset($_SESSION['reg_lname'])) {
																								echo $_SESSION['reg_lname'];
																							} ?>" required>
						<br>

						<input type="email" name="reg_email" placeholder="Email" value="<?php
																						if (isset($_SESSION['reg_email'])) {
																							echo $_SESSION['reg_email'];
																						} ?>" required>
						<br>

						<input type="email" name="reg_email2" placeholder="Confirm email" value="<?php
																									if (isset($_SESSION['reg_email2'])) {
																										echo $_SESSION['reg_email2'];
																									} ?>" required>
						<br>

						<?php //if (in_array("Email already in use<br>", $error_array)) echo "Email already in use<br>";
						//else if (in_array("Invalid email format<br>", $error_array)) echo "Invalid email format<br>";
						//else if (in_array("Email do not match<br>", $error_array)) echo "Email do not match<br>"; 
						?>

						<input type="password" name="reg_password" placeholder="Password" required>
						<br>
						<input type="password" name="reg_password2" placeholder="Confirm password" required>
						<br>

						<?php //if (in_array("Your password do not match<br>", $error_array)) echo "Your password do not match<br>"; 
						?>

						<input type="submit" name="register_button" id="button" value="Register">
						<br>
						<br>
						<?php //if (in_array("<span style = 'color: #14C800;'> You're all set! Go ahead and login! </span> <br>", $error_array)) echo "<span style = 'color: #14C800;'> You're all set! Go ahead and login! </span> <br>"; 
						?>


						<a href="login.php" id="signin" class="signin">Already have an account? Sign In</a>

					</form>
				</div>

			</div>
		</div>
		<script>
			const landingPage = document.querySelector('.landing');
			const landingBtn = document.querySelector('#landing-btn');
			landingBtn.addEventListener('click', () => {
				landingPage.classList.add('animated', 'slideOutUp');
			});

			$(document).ready(function() {

				//on click signup, hide login and show registration form
				$("#signup").click(function() {
					$("#first").slideUp("slow", function() {
						$("#second").slideDown("slow");
					});
				});
				//on click signup, hide registration form and login form
				$("#signin").click(function() {
					$("#second").slideUp("slow", function() {
						$("#first").slideDown("slow");
					});
				});

			});
		</script>
		<?php include '/xampp/htdocs/tutorial-35/starter_files/5pgtutorial/includes/footer.php'; ?>
		<?php include '/xampp/htdocs/tutorial-35/starter_files/5pgtutorial/includes/scripts.php'; ?>

</body>

</html>