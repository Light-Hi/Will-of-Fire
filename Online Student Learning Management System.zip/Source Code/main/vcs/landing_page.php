<?php 
require 'config/config.php';

require 'includes/form_handlers/register_handler.php';
require 'includes/form_handlers/login_handler.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<?php 
		include 'head.php'; 
	?>
</head>

<body>

	<?php include 'navbar.php'; ?>

	<div style="padding-top: 55px;">
	<div class="container">
		<div class="row justify-content-center text-center">
			<div class="col-10 py-5">
				<h1>Online Student Learning Management System (OSLMS)</h1>
			</div>
		</div>
	</div>
	<!--- Image Slider -->
	<div class="carousel slide" data-ride="carousel">
		<div class="carousel-inner">
			<div class="carousel-item active"><img src="img/img1.png"></div>
			<div class="carousel-item"><img src="img/img2.png"></div>
			<div class="carousel-item"><img src="img/img3.png"></div>
		</div>
	</div>
	<!--- End Image Slider -->

	<!--- Complete Bootstrap Course -->
	<div class="container">
		<div class="row justify-content-center text-center">
			<div class="col-10 py-5">
				<h2>Complete Online Student Learning Environment</h2>
				<p class="lead">The purpose of this website is to provide an online learning environment for students</p><a class="btn btn-purple btn-lg" href="https://gaapnet.blogspot.com/" target="_blank">Business Intelligence and Business Tactics</a>
			</div>
		</div>
	</div>
	<!--- Complete Bootstrap Course -->

	<?php include 'footer.php'; ?>
	<?php include 'scripts.php'; ?>
	
</body>
</html>





