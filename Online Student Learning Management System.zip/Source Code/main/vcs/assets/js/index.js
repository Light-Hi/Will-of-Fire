
document.getElementById('clickme').addEventListener('click',
function(){
    document.querySelector('.bd-modal').style.display = 'flex';
});