<!DOCTYPE html>
<html lang="en">
<head>
	<?php 
		include 'head.php'; 
	?>
</head>

<body>

    <?php include 'navbar.php'; ?>

	<div class="wrapper">
        <div class="landing">
            <div style="padding-top: 65px;">
			<h1 class="brand">Online Student Learning Management System</h1> <?php //needs bootstrap and padding?>
            <div class="landing__bg"></div>
            <div class="content">
	<div class="container py-3">
		<div class="row justify-content-center py-5">
			<div class="col-lg-6">
				<h3 class="pb-4">Learning has never been easier</h3>
				<p>I want to become one of the best software architects in the world</p>
				<p>Learning is fun</p>
				<a class="btn btn-purple btn-lg" href="https://www.cybrary.it">Try one of our courses for free!</a>
			</div>
			<div class="col-lg-6"><img class="img-fluid" src="img/course1.jpg">
		</div>
		</div>
	</div>

    <?php include '/xampp/htdocs/tutorial-35/starter_files/5pgtutorial/includes/footer.php'; ?>
	<?php include '/xampp/htdocs/tutorial-35/starter_files/5pgtutorial/includes/scripts.php'; ?>

</body>
</html>

