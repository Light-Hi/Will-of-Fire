<!DOCTYPE html>
<html lang="en">

<head>
	<?php
	include 'head.php';
	?>
</head>

<body>
	<?php include 'navbar.php'; ?>

		<style type="text/css">
			.input {
				border-radius: 5px;
				border: solid thin #aaa;
				padding: 10px;
				margin: 4px;
			}

			.button {
				border-radius: 5px;
				border: solid thin #aaa;
				padding: 10px;
				margin: 4px;
				cursor: pointer;
			}
		</style>
			<div class="wrapper">
        <div class="landing">
            <div style="padding-top: 65px;">
			<h1 class="brand">Online Student Learning Management System</h1> <?php //needs bootstrap and padding?>
            <div class="landing__bg"></div>
            <div class="content">
		<div style="padding-top: 65px;">
			<div class="col-md-4">
				
					<h3 class="text-center">This is the About Page</h3><strong>What is the information about the school?</strong>
					<p>image_Slider<br>
				Team</p>
				</div>

		<?php include 'footer.php'; ?>
		<?php include 'scripts.php'; ?>