<header>
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1" name="viewport">
	<title>Online Student Learning Environment</title>
	<link href="bootstrap-4.3.1-dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="style.css" rel="stylesheet">
</header>

<body> 
	<span>
		<?php

		if (isset($_SESSION['myname'])) {
			echo "Hi, " . $_SESSION['myname'];
		}
		?>
		<?php //if(access('ADMIN', true)): //Add things only an admin needs access to
		?>
		<?php //endif; 
		?>
	</span>
</body>