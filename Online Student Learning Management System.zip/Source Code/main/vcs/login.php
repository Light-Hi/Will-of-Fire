<!DOCTYPE html>
<html lang="en">

<head>
	<?php
	include 'head.php';
	?>
</head>

<body>
	<?php include 'navbar.php'; ?>
	<div class="wrapper">
        <div class="landing">
            <div style="padding-top: 65px;">
			<h1 class="brand">Online Student Learning Management System</h1> <?php //needs bootstrap and padding?>
            <div class="landing__bg"></div>
            <div class="content">
            <div style="padding-top: 50px;">
                <h2>Join Your Class From Anywhere Anytime</h2>
                <p></p>
                <span id="landing-btn">Login</span>
            </div>
        </div>


            <div id="first">
                <form action="landing_page.php" method="POST" id="login-form">
                    <input type="email" name="log_email" placeholder="Email address" value="<?php 
                                                                                            if (isset($_SESSION['log_email'])) {
                                                                                                echo $_SESSION['log_email'];
                                                                                            }
                                                                                            ?>" required>
                    <br>

                    <input type="password" name="log_password" placeholder="Password">
                    <br>
                    <?php //if (in_array("Email or password was incorrect<br>", $error_array)) echo "<span style='color:red; font-size:0.78rem;'>Email or password was incorrect<br><br></span>"; ?>

                    <input type="submit" name="login_button" id="button" value="Login">
                    <br>
                    <a href="Register.php" id="signup" class="signup">Need an account? Register Here</a>

                </form>
				<script>
        const landingPage = document.querySelector('.landing');
        const landingBtn = document.querySelector('#landing-btn');
        landingBtn.addEventListener('click', () => {
            landingPage.classList.add('animated', 'slideOutUp');
        });

        $(document).ready(function() {
   
        //on click signup, hide login and show registration form
        $("#signup").click(function()  {
            $("#first").slideUp("slow", function(){
                $("#second").slideDown("slow");
                });
            });
            //on click signup, hide registration form and login form
                $("#signin").click(function() {
                    $("#second").slideUp("slow", function(){
                        $("#first").slideDown("slow");
                });
            });

        });
 
    </script>

																						

	<?php include '/xampp/htdocs/tutorial-35/starter_files/5pgtutorial/includes/footer.php'; ?>
	<?php include '/xampp/htdocs/tutorial-35/starter_files/5pgtutorial/includes/scripts.php'; ?>

</body>

</html>